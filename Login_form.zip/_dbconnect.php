<?php
class dbConnect{
    function __construct(){
        require_once 'config.php';
        $conn = mysqli_connect($servername,$username,$password,$database);
        if(!$conn){
            die('Cannot connect to the databse due to'.mysqli_connect_error());
        }
        else{
            return $conn;
            // echo "Successfully connected";
        
         }
        }
}

?>